"""Dragon Seq Helper - control window.  Start it with Start.bat."""
import ctypes
import json
import os
import queue
import sys
import threading
import time
import traceback
import tkinter as tk

import dragon_seq_bot as core

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(HERE, "settings.json")
APP_NAME = "Dragon Seq Helper"

VK_F6 = 0x75
DEFAULTS = {"vk": VK_F6, "topmost": True}

# Keys the game itself uses (movement, skills, stop-training) - not allowed as the on/off hotkey.
GAME_KEYS = {0x57, 0x41, 0x53, 0x44,            # W A S D
             0x25, 0x26, 0x27, 0x28,            # arrow keys
             0x09,                              # Tab (stops training)
             0x54, 0x5A, 0x58,                  # T Z X
             *range(0x31, 0x39)}                # 1-8
# Keys ignored while choosing a hotkey (modifiers, Win keys, lock keys).
CAPTURE_SKIP = {0x10, 0x11, 0x12, 0x14, 0x5B, 0x5C, 0x90, 0x91, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5}
EXTENDED = {0x21, 0x22, 0x23, 0x24, 0x2D, 0x2E, 0x6F}   # PgUp PgDn End Home Ins Del Num/

BG, PANEL, FG, MUTED = "#1c1d22", "#2a2c33", "#ecedf0", "#9aa0ab"
GREEN, ORANGE, GREY, RED = "#2e9e5b", "#d98a1f", "#5b5f69", "#c0392b"


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s.update(json.load(f))
    except Exception:
        pass
    if not isinstance(s.get("vk"), int) or s["vk"] in GAME_KEYS:
        s["vk"] = VK_F6
    s["topmost"] = bool(s.get("topmost", True))
    return s


def save_settings(s):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(s, f)
    except Exception:
        pass


def vk_name(vk):
    if 0x70 <= vk <= 0x87:
        return f"F{vk - 0x6F}"
    if 0x30 <= vk <= 0x39 or 0x41 <= vk <= 0x5A:
        return chr(vk)
    try:
        user32 = ctypes.windll.user32
        scan = user32.MapVirtualKeyW(vk, 0)
        buf = ctypes.create_unicode_buffer(64)
        lparam = (scan << 16) | ((1 << 24) if vk in EXTENDED else 0)
        if user32.GetKeyNameTextW(lparam, buf, 64):
            return buf.value
    except Exception:
        pass
    return f"Key {vk}"


class Worker(threading.Thread):
    """Background loop: watches the Roblox window and types sequences while switched on."""

    def __init__(self, templates, title, events):
        super().__init__(daemon=True)
        self.events = events
        self.win = core.RobloxWindow(title)
        self.on = threading.Event()
        self.quit = threading.Event()
        self.bot = core.SequenceBot(
            templates, self.win.grab, self.win.press,
            log=lambda m: None,
            on_round=lambda seq, n: events.put(("round", seq, n)))

    def run(self):
        last = None
        last_seen = object()
        while not self.quit.is_set():
            if not self.on.is_set():
                last = None
                last_seen = object()
                time.sleep(0.05)
                continue
            try:
                self.win.refresh()
                if not self.win.found():
                    status = ("warn", "Roblox window not found")
                elif not self.win.focused():
                    status = ("warn", "Click the Roblox window (it needs focus to type)")
                else:
                    status = ("ok", "Running - waiting for the mini game")
                if status != last:
                    self.events.put(("status",) + status)
                    last = status
                if self.win.found():
                    self.bot.tick()
                    if self.bot.seen != last_seen:
                        last_seen = self.bot.seen
                        self.events.put(("seen", last_seen))
            except Exception as e:                      # keep running; show the problem in the window
                self.events.put(("status", "err", f"Error: {e}"))
                last = None
                time.sleep(1.0)
            time.sleep(core.POLL_SECONDS)


class App:
    def __init__(self, root, templates):
        self.root = root
        self.s = load_settings()
        self.events = queue.Queue()
        self.worker = Worker(templates, core.WINDOW_TITLE, self.events)
        self.worker.start()
        self.capturing = False
        self.was_down = core.key_down(self.s["vk"])      # don't fire if the key happens to be held at launch
        self.running = False
        self.build()
        self.apply_topmost()
        self.refresh_view()
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.poll()

    # ---------- layout ----------
    def build(self):
        r = self.root
        r.title(APP_NAME)
        r.configure(bg=BG)
        r.resizable(False, False)
        r.geometry("+40+40")

        tk.Label(r, text="DRAGON SEQ HELPER", bg=BG, fg=FG, font=("Segoe UI", 11, "bold")).pack(pady=(14, 2))
        tk.Label(r, text="W / A / S / D sequence mini game", bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack()

        self.status = tk.Label(r, text="", bg=GREY, fg="white", font=("Segoe UI", 10, "bold"),
                               width=36, wraplength=270, pady=7)
        self.status.pack(padx=16, pady=(14, 10))

        self.btn = tk.Button(r, text="", font=("Segoe UI", 14, "bold"), fg="white", bd=0, relief="flat",
                             activeforeground="white", cursor="hand2", width=16, pady=10, command=self.on_button)
        self.btn.pack(pady=(0, 12))

        row = tk.Frame(r, bg=PANEL)
        row.pack(fill="x", padx=16, pady=4)
        tk.Label(row, text="On/off hotkey", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(side="left", padx=(10, 6), pady=8)
        self.key_lbl = tk.Label(row, text="", bg=PANEL, fg=FG, font=("Segoe UI", 10, "bold"))
        self.key_lbl.pack(side="left")
        self.key_btn = tk.Button(row, text="Change", font=("Segoe UI", 9), bd=0, bg="#3a3d46", fg=FG,
                                 activebackground="#4a4e59", activeforeground=FG, cursor="hand2",
                                 padx=10, command=self.start_capture)
        self.key_btn.pack(side="right", padx=8)

        self.top_var = tk.BooleanVar(value=self.s["topmost"])
        tk.Checkbutton(r, text="Always on top", variable=self.top_var, command=self.on_topmost,
                       bg=BG, fg=FG, activebackground=BG, activeforeground=FG, selectcolor=PANEL,
                       font=("Segoe UI", 10), cursor="hand2").pack(anchor="w", padx=14, pady=(8, 0))

        tk.Button(r, text="Save debug screenshot", font=("Segoe UI", 9), bd=0, bg="#3a3d46", fg=FG,
                  activebackground="#4a4e59", activeforeground=FG, cursor="hand2", padx=10, pady=3,
                  command=self.save_debug).pack(anchor="w", padx=16, pady=(8, 0))

        self.seen_lbl = tk.Label(r, text="Seeing: -", bg=BG, fg=FG, font=("Segoe UI", 10, "bold"))
        self.seen_lbl.pack(pady=(10, 0))
        self.info = tk.Label(r, text="Last sequence: -      Typed: 0", bg=BG, fg=MUTED, font=("Segoe UI", 9))
        self.info.pack(pady=(2, 0))
        self.hint = tk.Label(r, text="", bg=BG, fg=MUTED, font=("Segoe UI", 8), wraplength=270, justify="center")
        self.hint.pack(padx=16, pady=(4, 14))

    # ---------- actions ----------
    def on_button(self):
        if self.running:
            self.stop()
        else:
            self.start(focus_game=True)

    def toggle(self):                       # hotkey path - the player is already in the game
        if self.running:
            self.stop()
        else:
            self.start(focus_game=False)

    def start(self, focus_game):
        self.worker.bot.reset()
        self.running = True
        self.worker.on.set()
        if focus_game:
            try:
                self.worker.win.refresh()
                if self.worker.win.found() and not self.worker.win.focused():
                    self.worker.win.focus()
            except Exception:
                pass
        self.set_status("ok", "Starting...")
        self.refresh_view()

    def stop(self):
        self.running = False
        self.worker.on.clear()
        self.set_status("off", "Stopped")
        self.refresh_view()

    def on_topmost(self):
        self.s["topmost"] = bool(self.top_var.get())
        save_settings(self.s)
        self.apply_topmost()

    def save_debug(self):
        """Save what the helper sees right now, so a problem can be diagnosed from the files."""
        try:
            img = self.worker.win.snapshot()
            if img is None:
                self.hint.config(text="Roblox window not found - open the game first, then try again.")
                return
            import cv2
            cv2.imwrite(os.path.join(HERE, "debug_frame.png"), img)
            row = core.read_row(img, self.worker.bot.t)
            with open(os.path.join(HERE, "debug_reading.txt"), "w", encoding="utf-8") as f:
                f.write(f"window size: {img.shape[1]}x{img.shape[0]}\nreading: {row}\n")
            self.hint.config(text="Saved debug_frame.png and debug_reading.txt in the app folder - send me both.")
        except Exception as e:
            log_error()
            self.hint.config(text=f"Could not save debug files: {e}")

    def apply_topmost(self):
        self.root.attributes("-topmost", bool(self.s["topmost"]))

    def start_capture(self):
        self.capturing = True
        self.key_btn.config(text="Press a key...")
        self.hint.config(text="Press the key you want (Esc to cancel). F-keys are safest - the game uses W A S D, 1-8, T, Z, X and Tab.")

    def end_capture(self, note=""):
        self.capturing = False
        self.key_btn.config(text="Change")
        self.hint.config(text=note)
        self.refresh_view()

    # ---------- view ----------
    def set_status(self, level, text):
        color = {"ok": GREEN, "warn": ORANGE, "off": GREY, "err": RED}[level]
        self.status.config(text=text, bg=color)

    def refresh_view(self):
        self.key_lbl.config(text=core_key_label(self.s["vk"]))
        if self.running:
            self.btn.config(text="\u25A0  STOP", bg=RED, activebackground="#a93226")
        else:
            self.btn.config(text="\u25B6  START", bg=GREEN, activebackground="#257d49")
            self.set_status("off", "Stopped")

    # ---------- polling (main thread) ----------
    def poll(self):
        try:
            if self.capturing:
                self.poll_capture()
            else:
                down = core.key_down(self.s["vk"])
                if down and not self.was_down:
                    self.toggle()
                self.was_down = down
            self.drain()
        except Exception:
            log_error()
        self.root.after(20, self.poll)

    def poll_capture(self):
        for vk in range(0x08, 0xE0):
            if vk in CAPTURE_SKIP or not core.key_down(vk):
                continue
            if vk == 0x1B:
                self.end_capture("Cancelled.")
            elif vk in GAME_KEYS:
                self.hint.config(text=f"{vk_name(vk)} is used by the game - pick another key.")
            else:
                self.s["vk"] = vk
                save_settings(self.s)
                self.was_down = True                 # wait for release before the new hotkey can fire
                self.end_capture(f"Hotkey set to {vk_name(vk)}.")
            return

    def drain(self):
        last_seq = None
        while True:
            try:
                ev = self.events.get_nowait()
            except queue.Empty:
                break
            if ev[0] == "status" and self.running:
                self.set_status(ev[1], ev[2])
            elif ev[0] == "round":
                last_seq = ev
            elif ev[0] == "seen":
                txt = "?" if ev[1] is None else (ev[1] or "-")
                self.seen_lbl.config(text=f"Seeing: {txt}")
        if last_seq:
            self.info.config(text=f"Last sequence: {last_seq[1]}      Typed: {last_seq[2]}")

    def close(self):
        self.worker.quit.set()
        self.root.destroy()


def core_key_label(vk):
    return vk_name(vk)


def log_error():
    try:
        with open(os.path.join(HERE, "error.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n" + traceback.format_exc() + "\n")
    except Exception:
        pass


def main():
    core.enable_dpi_awareness()
    templates = core.load_templates(os.path.join(HERE, "letters"))
    root = tk.Tk()
    App(root, templates)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log_error()
        try:
            from tkinter import messagebox
            messagebox.showerror(APP_NAME, f"Something went wrong:\n\n{e}\n\nDetails were saved to error.log")
        except Exception:
            pass
        sys.exit(1)
