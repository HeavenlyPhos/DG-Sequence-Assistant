@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo First-time setup needed - running Install.bat...
    call Install.bat
    exit /b
)
start "" ".venv\Scripts\pythonw.exe" gui.py
