DRAGON SEQ HELPER
=================
First time:  double-click  Install.bat   (installs everything, makes a desktop shortcut, then opens the app)
After that:  double-click  Start.bat  or the "Dragon Seq Helper" desktop shortcut

Using it
- Open Roblox and get to the W/A/S/D mini game. Keep the Roblox window visible (not minimised).
- Press START (or your hotkey, default F6). Press it again to stop.
- "Change" next to the hotkey lets you pick any key (not W/A/S/D, arrows, Tab, T, Z, X, 1-8: the game uses those).
- "Always on top" keeps the small window above the game.
- Keys are only sent while Roblox is the focused window. If the status turns orange, click on the game.

The "Seeing:" line shows what the helper currently reads on screen (e.g. ASD). "?" means it sees letters but
isn't sure yet (it waits instead of guessing).

Troubleshooting
- Nothing happens: the status line tells you why (window not found / not focused).
- Wrong letters or nothing detected: click "Save debug screenshot" while the mini game is on screen, then send me
  debug_frame.png and debug_reading.txt from this folder.
- Errors are written to error.log in this folder.
