"""
Dragon Generations - W/A/S/D sequence mini game helper: core logic (Windows).

Watches ONLY the Roblox window (screen capture) and presses the keys shown on screen.
It does not touch the game's memory or code.

Normally you don't run this file - double-click Start.bat, which opens the control window (gui.py).

Check detection on a screenshot (works on any OS with opencv-python-headless + numpy):
    python dragon_seq_bot.py --test screenshot.png
"""
import argparse
import ctypes
import os
import sys
import time
from ctypes import wintypes

import cv2
import numpy as np

# ----------------------------- detection -----------------------------
# Search band (fractions of the Roblox client area). Deliberately generous: the row is located by what it
# looks like, not by an exact position, so different window sizes / aspect ratios still work.
BAND = (0.22, 0.66, 0.78, 0.96)    # x0, y0, x1, y1
TPL = 24


def face_masks(bgr):
    """Boolean masks for the three letter-face colours. Independent of what is behind the letters."""
    b = bgr[..., 0].astype(np.int16)
    g = bgr[..., 1].astype(np.int16)
    r = bgr[..., 2].astype(np.int16)
    mx = np.maximum(np.maximum(r, g), b)
    mn = np.minimum(np.minimum(r, g), b)
    spread = mx - mn
    white = (mn >= 215) & (spread <= 40)                                   # current letter
    green = (g >= 200) & (g - r >= 60) & (g - b >= 60)                     # already typed
    gray = (mn >= 85) & (mx <= 160) & (spread <= 26)                       # upcoming
    return white, gray, green


def letter_mask(bgr):
    w, gr, gn = face_masks(bgr)
    return ((w | gr | gn).astype(np.uint8)) * 255


def _norm_glyph(mask_crop):
    return cv2.resize(mask_crop, (TPL, TPL), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0


def load_templates(folder):
    tpls = {}
    for key in "WASD":
        path = os.path.join(folder, f"{key}1.png")
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(f"Missing template image: {path}")
        m = letter_mask(img)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((2, 2), np.uint8))
        n, _, stats, _ = cv2.connectedComponentsWithStats(m)
        if n < 2:
            raise ValueError(f"No letter found in {path}")
        i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        x, y, w, h = stats[i, :4]
        tpls[key] = (_norm_glyph(m[y:y + h, x:x + w]), w / h)
    return tpls


def _classify(glyph, aspect, templates):
    best, best_s = None, -1.0
    for key, (t, asp) in templates.items():
        s = float(np.minimum(glyph, t).sum()) / (float(np.maximum(glyph, t).sum()) + 1e-6)
        s -= 0.35 * abs(aspect - asp)
        if s > best_s:
            best, best_s = key, s
    return best, best_s


def _outlined(dark, comp, H):
    """Letters have a thick black outline: most pixels in a thin ring around the face must be dark."""
    r_out = max(3, int(round(0.0026 * H)))          # outline is ~3px thick at 1080p
    k_out = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r_out + 1, 2 * r_out + 1))
    ring = cv2.dilate(comp, k_out) & ~cv2.dilate(comp, np.ones((3, 3), np.uint8))
    n = int(ring.sum())
    if n == 0:
        return False
    return float((dark & (ring > 0)).sum()) / n >= 0.55


def read_row(client_bgr, templates, min_score=0.55):
    """[(key, state), ...] left->right; [] if no letters; None if letters are there but not readable yet."""
    H, W = client_bgr.shape[:2]
    x0, y0, x1, y1 = BAND
    ox, oy = int(x0 * W), int(y0 * H)
    roi = client_bgr[oy:int(y1 * H), ox:int(x1 * W)]
    white, gray, green = face_masks(roi)
    mask = ((white | gray | green).astype(np.uint8)) * 255
    dark = roi.astype(np.int16).sum(axis=2) < 3 * 70
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=4)

    cands = []      # ringed, letter-sized blobs: (x, y, w, h, key, score, state)
    small = []      # ringed blobs that are too small to be a finished letter (zoom-in animation)
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        is_small = (0.008 * H <= h < 0.016 * H and 0.005 * H <= w <= 0.11 * H)
        if not ((0.016 * H <= h <= 0.09 * H and 0.009 * H <= w <= 0.13 * H) or is_small) or area < 0.25 * w * h:
            continue
        comp = ((lab[y:y + h, x:x + w] == i).astype(np.uint8))
        # ring check on a padded copy so the ring is not cut off at the crop edge
        pad = max(4, int(0.006 * H))
        y_a, y_b = max(0, y - pad), min(roi.shape[0], y + h + pad)
        x_a, x_b = max(0, x - pad), min(roi.shape[1], x + w + pad)
        full = (lab[y_a:y_b, x_a:x_b] == i).astype(np.uint8)
        if not _outlined(dark[y_a:y_b, x_a:x_b], full, H):
            continue
        key, s = _classify(_norm_glyph(comp * 255), w / h, templates)
        if is_small:
            if s >= 0.45:
                small.append((x, y, w, h))
            continue
        faces = roi[y:y + h, x:x + w][comp > 0]
        wc = int(white[y:y + h, x:x + w][comp > 0].sum())
        gc = int(green[y:y + h, x:x + w][comp > 0].sum())
        state = "green" if gc > wc and gc > 0.3 * len(faces) else ("white" if wc > 0.5 * len(faces) else "gray")
        cands.append((x, y, w, h, key, s, state))
    if not cands:
        return []

    # cluster blobs into rows by vertical centre
    cands.sort(key=lambda c: c[1] + c[3] / 2)
    rows, cur = [], [cands[0]]
    for c in cands[1:]:
        ref = sum(k[3] for k in cur) / len(cur)
        if abs((c[1] + c[3] / 2) - sum(k[1] + k[3] / 2 for k in cur) / len(cur)) <= 0.6 * ref:
            cur.append(c)
        else:
            rows.append(cur)
            cur = [c]
    rows.append(cur)

    best_row, best_val = None, -1.0
    for r in rows:
        centre = sum(c[0] + c[2] / 2 for c in r) / len(r) + ox        # row's mean x, in client coords
        if abs(centre - W / 2) > 0.10 * W:
            continue                                                   # the sequence row is centred
        val = sum(c[5] for c in r) + len(r)
        if val > best_val:
            best_row, best_val = r, val
    if best_row is None:
        return []
    row = sorted(best_row)
    ymid = sum(c[1] + c[3] / 2 for c in row) / len(row)
    rh = sum(c[3] for c in row) / len(row)
    if any(abs((sy + sh / 2) - ymid) <= 0.8 * rh for _, sy, _, sh in small):
        return None                                                    # a letter in this row is still zooming in
    if any(c[5] < min_score for c in row):
        return None                                                    # a letter-shaped blob we can't identify
    hs = [c[3] for c in row]
    if max(hs) > 1.45 * min(hs):
        return None
    # A complete row is centred on the screen with evenly small gaps. If a letter was lost (e.g. it blended into
    # the background) the row looks off-centre or has a hole - refuse to guess.
    centre = sum(c[0] + c[2] / 2 for c in row) / len(row) + ox
    if abs(centre - W / 2) > 0.009 * W:
        return None
    gaps = [row[i + 1][0] - (row[i][0] + row[i][2]) for i in range(len(row) - 1)]
    if gaps and max(gaps) > 0.065 * H:
        return None
    return [(c[4], c[6]) for c in row]


# ----------------------------- timing / behaviour settings -----------------------------
POLL_SECONDS = 0.03        # how often the screen is checked
STABLE_SECONDS = 0.30      # a new sequence must read identically this long before typing (skips the zoom-in animation)
RETYPE_SECONDS = 1.20      # if the same fresh sequence is still showing this long after typing, type it again
KEY_HOLD = 0.035           # how long each key is held down
KEY_GAP = 0.045            # pause between keys
WINDOW_TITLE = "Roblox"
SCAN_CODES = {"W": 0x11, "A": 0x1E, "S": 0x1F, "D": 0x20}


class SequenceBot:
    """State machine. grab() -> BGR client-area image; press(list_of_keys) -> False if it could not type;
    now() -> seconds; on_round(seq, total) is called after each typed sequence."""

    def __init__(self, templates, grab, press, now=time.time, log=print, on_round=None):
        self.t, self.grab, self.press, self.now = templates, grab, press, now
        self.log, self.on_round = log, on_round
        self.rounds = 0
        self.reset()

    def reset(self):
        self.state = "IDLE"
        self.cand = None
        self.cand_since = 0.0
        self.typed_seq = None
        self.typed_at = 0.0
        self.seen = ""          # what the last frame looked like: "" = nothing, None = unsure, else e.g. "ASD"

    @staticmethod
    def _fresh(row):
        """A brand-new round: letters visible, none green yet, first one highlighted."""
        return bool(row) and all(s != "green" for _, s in row) and row[0][1] == "white"

    def tick(self):
        row = read_row(self.grab(), self.t)
        t = self.now()
        seq = "".join(k for k, _ in row) if row else ""
        self.seen = None if row is None else seq

        if self.state == "IDLE":
            if row is not None and self._fresh(row):
                if seq == self.cand:
                    if t - self.cand_since >= STABLE_SECONDS:
                        if self.press(list(seq)) is False:
                            return                      # couldn't type (e.g. Roblox not focused) - retry next tick
                        self.rounds += 1
                        self.log(f"round {self.rounds}: {seq}")
                        if self.on_round:
                            self.on_round(seq, self.rounds)
                        self.typed_seq, self.typed_at, self.state = seq, t, "TYPED"
                else:
                    self.cand, self.cand_since = seq, t
            else:
                self.cand = None
        else:  # TYPED: wait until the screen moves on (turns green / clears / changes)
            if row is None:
                return
            moved_on = (not row) or any(s == "green" for _, s in row) or seq != self.typed_seq
            if moved_on:
                self.state, self.cand = "IDLE", None
            elif t - self.typed_at > RETYPE_SECONDS and self._fresh(row):
                self.log("same sequence still showing - typing it again")
                self.state, self.cand = "IDLE", None


# ----------------------------- Windows layer: window, capture, keys -----------------------------
ULONG_PTR = ctypes.c_size_t
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]


class _INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", _MOUSEINPUT), ("ki", _KEYBDINPUT), ("hi", _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUT_UNION)]


def enable_dpi_awareness():
    """Call once at startup so window coordinates are real pixels at any Windows display scaling."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def find_client_rect(title):
    """((left, top, width, height) of the Roblox client area, hwnd) or (None, None)."""
    user32 = ctypes.windll.user32
    hwnd = user32.FindWindowW(None, title)
    if not hwnd or user32.IsIconic(hwnd):
        return None, None
    rc = wintypes.RECT()
    user32.GetClientRect(hwnd, ctypes.byref(rc))
    pt = wintypes.POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    if rc.right < 200 or rc.bottom < 200:
        return None, None
    return {"left": pt.x, "top": pt.y, "width": rc.right, "height": rc.bottom}, hwnd


def is_foreground(hwnd):
    return ctypes.windll.user32.GetForegroundWindow() == hwnd


def focus_window(hwnd):
    user32 = ctypes.windll.user32
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)        # SW_RESTORE
    user32.SetForegroundWindow(hwnd)


def key_down(vk):
    """True while the given virtual-key is held (works even when another window has focus)."""
    return bool(ctypes.windll.user32.GetAsyncKeyState(vk) & 0x8000)


def _send_scan(scan, up):
    inp = _INPUT(type=1)  # INPUT_KEYBOARD
    inp.ki = _KEYBDINPUT(0, scan, KEYEVENTF_SCANCODE | (KEYEVENTF_KEYUP if up else 0), 0, 0)
    ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))


def send_keys(keys):
    """Press W/A/S/D one after another using hardware scan codes (what games listen for)."""
    for k in keys:
        scan = SCAN_CODES[k.upper()]
        _send_scan(scan, False)
        time.sleep(KEY_HOLD)
        _send_scan(scan, True)
        time.sleep(KEY_GAP)


class RobloxWindow:
    """Finds the Roblox window, captures its client area, and types into it only while it has focus."""

    def __init__(self, title=WINDOW_TITLE):
        self.title, self.rect, self.hwnd, self._sct = title, None, None, None

    def refresh(self):
        self.rect, self.hwnd = find_client_rect(self.title)

    def found(self):
        return self.rect is not None

    def focused(self):
        return self.hwnd is not None and is_foreground(self.hwnd)

    def focus(self):
        if self.hwnd:
            focus_window(self.hwnd)

    def grab(self):
        self.refresh()                      # re-read each frame so moving / resizing the window just works
        if self.rect is None:
            return np.zeros((10, 10, 3), np.uint8)
        if self._sct is None:               # created lazily in whichever thread captures (mss is per-thread)
            import mss
            self._sct = mss.mss()
        shot = np.array(self._sct.grab(self.rect))      # BGRA
        return cv2.cvtColor(shot, cv2.COLOR_BGRA2BGR)

    def snapshot(self):
        """One-off capture of the Roblox client area (own capture object, safe from any thread)."""
        self.refresh()
        if self.rect is None:
            return None
        import mss
        with mss.mss() as s:
            shot = np.array(s.grab(self.rect))
        return cv2.cvtColor(shot, cv2.COLOR_BGRA2BGR)

    def press(self, keys):
        if not self.focused():
            return False
        send_keys(keys)
        return True


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--test", metavar="IMAGE", required=True, help="read the sequence from a screenshot and exit")
    ap.add_argument("--letters", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "letters"))
    a = ap.parse_args()
    templates = load_templates(a.letters)
    img = cv2.imread(a.test, cv2.IMREAD_COLOR)
    if img is None:
        sys.exit(f"Could not open {a.test}")
    row = read_row(img, templates)
    mark = {"white": "(current)", "gray": "", "green": "(done)"}
    print("Nothing found" if not row else "  ".join(f"{k}{mark[s]}" for k, s in row))


if __name__ == "__main__":
    main()
