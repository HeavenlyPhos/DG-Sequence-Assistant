@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Dragon Seq Helper - Setup
echo ============================================
echo   Dragon Seq Helper - one-time setup
echo ============================================
echo.

set "PYEXE="

rem --- 1) look for a compatible Python (3.10 - 3.13) ---
for %%V in (3.12 3.13 3.11 3.10) do (
    if not defined PYEXE (
        py -%%V --version >nul 2>&1
        if !errorlevel!==0 set "PYEXE=py -%%V"
    )
)
if not defined PYEXE (
    set "PYVER="
    for /f "tokens=2" %%A in ('python --version 2^>nul') do set "PYVER=%%A"
    for %%V in (3.10 3.11 3.12 3.13) do if "!PYVER:~0,4!"=="%%V" set "PYEXE=python"
)

rem --- 2) none found: install Python 3.12 automatically ---
if not defined PYEXE (
    echo Python was not found. Installing Python 3.12 - this can take a few minutes...
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set PYEXE="%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    if exist "%ProgramFiles%\Python312\python.exe" set PYEXE="%ProgramFiles%\Python312\python.exe"
)
if not defined PYEXE (
    echo.
    echo Could not install Python automatically.
    echo A download page will open. Install Python 3.12, tick "Add python.exe to PATH",
    echo then double-click Install.bat again.
    start "" "https://www.python.org/downloads/windows/"
    pause
    exit /b 1
)

rem --- 3) private environment + packages ---
if not exist ".venv\Scripts\python.exe" (
    echo Creating a private Python environment...
    %PYEXE% -m venv .venv
    if errorlevel 1 goto :fail
)
echo Installing required packages - this takes a minute...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -c "import cv2, numpy, mss, tkinter" >nul 2>&1
if errorlevel 1 goto :fail

rem --- 4) desktop shortcut (optional) ---
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Dragon Seq Helper.lnk'); $s.TargetPath='%~dp0Start.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()" >nul 2>&1

echo.
echo ============================================
echo   All done! Starting Dragon Seq Helper...
echo   Next time: double-click Start.bat or the
echo   "Dragon Seq Helper" shortcut on your desktop.
echo ============================================
timeout /t 3 >nul
start "" "%~dp0Start.bat"
exit /b 0

:fail
echo.
echo Setup failed. Scroll up for the error message, or send me a screenshot of this window.
pause
exit /b 1
